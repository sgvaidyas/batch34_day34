﻿var products=[]
function addprod() {
    var pid = document.getElementById("pid").value;
    var pname = document.getElementById("pname").value;
    var price = document.getElementById("price").value;

    ob = {
        PRODID:pid,
        PRODNAME: pname,
        PRODPRICE: price
    }
    products.push(ob);
    clear();
    showdetails()
}

function showdetails() {
    var table = document.getElementById("myprod");
    table.innerHTML = "";
    showheaders();
    for (let i = 0; i < products.length; i++) {
        tr = table.insertRow();
        td = document.createElement('td');
        td.innerHTML = products[i].PRODID;
        tr.appendChild(td);
        td = document.createElement('td');
        td.innerHTML = products[i].PRODNAME;
        tr.appendChild(td);
        td = document.createElement('td');
        td.innerHTML = products[i].PRODPRICE;
        tr.appendChild(td);
        td = document.createElement('td');
        td.innerHTML = "REMOVE";
        td.setAttribute("onclick","remove(i)");
        tr.appendChild(td);
        td = document.createElement('td');
        td.innerHTML = "UPDATE";
        tr.appendChild(td);
    }
}
function showheaders() {
    var table = document.getElementById("myprod");
    table.innerHTML = "";
    headers=["PID","PNAME","PRICE","REMOVE","UPDATE"]
    tr = table.insertRow();
    for (let i = 0; i < headers.length; i++) {
        th = document.createElement('th');
        th.innerHTML = headers[i];
        tr.appendChild(th);
    }
}
function remove(ind) {
    products.splice(ind, 1);
    showdetails();
    console.log(products)
}
function clear() {
    document.getElementById("pid").value = 0;
    document.getElementById("pname").value = "";
    document.getElementById("price").value = 0;

}
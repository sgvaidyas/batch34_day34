﻿function showdata() {
    var date = new Date();


    var hh = date.getHours();
    var mm = date.getMinutes();
    var ss = date.getSeconds();
    var text = "AM";


    if (hh >= 12) 
        text = "PM";

    hh = (hh > 12) ? hh - 12 : hh;  

    hh = (hh < 10) ? "0" + hh : hh;
    mm = (mm < 10) ? "0" + mm : mm;
    ss = (ss < 10) ? "0" + ss : ss;


    strtime = hh + ":" + mm + ":" + ss + " " + text
    document.getElementById("gettime").innerHTML = strtime;

    setTimeout(showdata, 1000);

}
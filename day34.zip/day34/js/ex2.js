﻿
function arriter() {
    a = [22, 3, 44, 5, 66, 7]
    for (let i = 0; i < a.length; i++)
        console.log(a[i]);
}


function arriter1() {
    var txt = "";
    var a = [22, 3, 44, 5, 66, 7]
    a.forEach(fun);
    console.log(txt)
    function fun(value, index, a) {
        txt = txt + value + " ";
        //txt = txt + a[index] + " ";
    }
}
function arrmap() {
    var a = [22, 3, 44, 5, 66, 7]
    var x = a.map(fun1)
    console.log(x)
    function fun1(value, index, a) {
        return value + value
    }
}
function arrfilter() {
    var a = [22, 7, 99, 3, 44, 5, 66, 7]
    var x = a.filter(fun2)
    console.log(x)
    function fun2(value, index, a) {
        return value%2==0
    }
}
function arrreduce() {
    var a = [22, 7, 99, 3, 44, 5, 66, 7]
    var x = a.reduce(fun3)
    console.log(x)
    function fun3(total, value, index, a) {
        return total + value
    }
}

function arrreduceeven() {
    var a = [22, 7, 99, 3, 44, 5, 66, 7]
    var x = a.reduce(fun3)
    console.log(x)
    function fun3(total, value, index, a) {
        if (value % 2 == 0)
            return total + value;
        else
            return total
    }
}

function arrreduceeven_1() {
    var a = [22, 7, 99, 3, 44, 5, 66, 7]
    var x = a.reduce(fun3,50)
    console.log(x)
    function fun3(total, value, index, a) {
        if (value % 2 == 0)
            return total + value;
        else
            return total
    }
}

function arrEvery() {
    a = [11, 22, 33, 23, 55, 66]

    x = a.every(fun4);
    console.log(x)

    function fun4(value, index, a) {
        return value<100
    }
}
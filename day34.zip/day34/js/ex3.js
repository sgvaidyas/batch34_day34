﻿var studlist = [];
function adddetails() {
    var name = document.getElementById("fname").value;
    var marks = document.getElementById("marks").value;

    var ob = { Name: name, Marks: marks };

    studlist.push(ob);
}

function minmarks() {

    len = studlist.length;

    min = Infinity;

    while (len--) {
        if (studlist[len].Marks < min) {
            min = studlist[len].Marks
        }
    }
    document.getElementById("lowest").innerHTML = "MINIMUM MARKS = " + min;

    var table = document.getElementById("minmarksdetails");
    tr = table.insertRow();
    var th = document.createElement('th');
    th.innerHTML = "NAME";
    tr.appendChild(th);
    var th = document.createElement('th');
    th.innerHTML = "MARKS";
    tr.appendChild(th);

    for (let i = 0; i < studlist.length; i++) {
        if (studlist[i].Marks == min) {
            tr = table.insertRow();
            var td = document.createElement('td');
            td.innerHTML = studlist[i].Name
            tr.appendChild(td);
            var td = document.createElement('td');
            td.innerHTML = studlist[i].Marks
            tr.appendChild(td);
        }
    }

}

function maxmarks() {

    len = studlist.length;

    max = -Infinity;

    while (len--) {
        if (studlist[len].Marks > max) {
            max = studlist[len].Marks
        }
    }
    document.getElementById("maximum").innerHTML = "MAXIMUM MARKS = " + max;
}
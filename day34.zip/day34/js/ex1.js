﻿function getslice() {
    a = [11, 22, 33, 44, 55, 66, 77, 88]
    x = a.slice(3)
    console.log(x)

    x = a.slice(2, 5)
    console.log(x)


    x = a.slice(2, 9)
    console.log(x)


    x = a.slice(1, 7)
    x = x.reverse();
    console.log(x)


    //a = [22, 3, 44,5,44, 5, 7, 88, 1]
    a=["aaaa", "ccc","abbb","Apple"]
    console.log(a.sort(cmp))
}
function cmp(m, n) {
    if (m<n)
        return -1;
    else if (m>n)
        return 1;
    else
        return 0;
}